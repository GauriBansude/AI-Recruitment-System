"""AI Recruitment System - Flask app.

Run:  python app.py      then open http://127.0.0.1:5000   (login: admin / admin123)
"""
import os
import uuid
from functools import wraps

from flask import (Flask, flash, jsonify, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash
from werkzeug.utils import secure_filename

from models import candidate_model as cm
from models.database import get_db, init_db
from modules.job_matcher import match_candidate_to_job
from modules.ranking import final_score, rank_applications
from modules.recommendation import recommend_jobs, skill_gap_advice
from modules.resume_parser import allowed_file, extract_text
from modules.skill_extractor import extract_profile, parse_skill_list

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads", "resumes")
STATUSES = ["new", "shortlisted", "interview", "offer", "rejected"]

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-in-production")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB per upload
os.makedirs(UPLOAD_DIR, exist_ok=True)
init_db()


# ---------------- helpers ----------------
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def run_matching(job_id=None, candidate_id=None):
    """(Re)score applications. Pass a job, a candidate, or neither for everything."""
    jobs = [cm.get_job(job_id)] if job_id else cm.list_jobs()
    candidates = [cm.get_candidate(candidate_id)] if candidate_id else cm.list_candidates()
    for job in jobs:
        for cand in candidates:
            result = match_candidate_to_job(cand, job)
            result["final_score"] = final_score(result)
            cm.upsert_application(job["id"], cand["id"], result)


@app.template_filter("csv")
def csv_filter(value):
    return [x for x in (value or "").split(",") if x]


@app.context_processor
def inject_globals():
    return {"STATUSES": STATUSES}


# ---------------- auth ----------------
@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE username = ?",
                            (request.form.get("username", "").strip(),)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], request.form.get("password", "")):
            session["user"] = user["username"]
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") else url_for("dashboard"))
        flash("Wrong username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------- dashboard ----------------
@app.route("/dashboard")
@login_required
def dashboard():
    data = cm.analytics()
    conn = get_db()
    top = conn.execute(
        """SELECT a.final_score, a.job_id, a.candidate_id, c.name, j.title
           FROM applications a JOIN candidates c ON c.id = a.candidate_id
           JOIN jobs j ON j.id = a.job_id
           WHERE j.status = 'open' ORDER BY a.final_score DESC LIMIT 5""").fetchall()
    conn.close()
    return render_template("dashboard.html", data=data, top=top, jobs=cm.list_jobs("open")[:5])


# ---------------- jobs ----------------
@app.route("/jobs")
@login_required
def jobs():
    return render_template("jobs.html", jobs=cm.list_jobs())


@app.route("/jobs/new", methods=["GET", "POST"])
@login_required
def create_job():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        if not title or not description:
            flash("Add a job title and a description.", "error")
            return render_template("create_job.html", form=request.form)
        try:
            min_exp = float(request.form.get("min_experience") or 0)
        except ValueError:
            min_exp = 0
        skills = ",".join(parse_skill_list(request.form.get("required_skills", "")))
        job_id = cm.add_job(title, request.form.get("department", "").strip(),
                            request.form.get("location", "").strip(), description, skills, min_exp)
        run_matching(job_id=job_id)
        flash("Job posted. Existing candidates were matched against it.", "ok")
        return redirect(url_for("job_detail", job_id=job_id))
    return render_template("create_job.html", form={})


@app.route("/jobs/<int:job_id>")
@login_required
def job_detail(job_id):
    job = cm.get_job(job_id)
    if not job:
        return redirect(url_for("jobs"))
    status = request.args.get("status", "")
    ranked = rank_applications(cm.applications_for_job(job_id))
    if status in STATUSES:
        ranked = [r for r in ranked if r["status"] == status]
    return render_template("job_detail.html", job=job, ranked=ranked, active_status=status)


@app.route("/jobs/<int:job_id>/rematch", methods=["POST"])
@login_required
def rematch_job(job_id):
    run_matching(job_id=job_id)
    flash("Scores refreshed.", "ok")
    return redirect(url_for("job_detail", job_id=job_id))


@app.route("/jobs/<int:job_id>/toggle", methods=["POST"])
@login_required
def toggle_job(job_id):
    job = cm.get_job(job_id)
    if job:
        cm.set_job_status(job_id, "closed" if job["status"] == "open" else "open")
    return redirect(url_for("job_detail", job_id=job_id))


@app.route("/jobs/<int:job_id>/delete", methods=["POST"])
@login_required
def delete_job(job_id):
    cm.delete_job(job_id)
    flash("Job deleted.", "ok")
    return redirect(url_for("jobs"))


# ---------------- candidates ----------------
@app.route("/candidates", methods=["GET", "POST"])
@login_required
def candidates():
    if request.method == "POST":
        files = [f for f in request.files.getlist("resumes") if f and f.filename]
        if not files:
            flash("Choose at least one resume (PDF, DOCX or TXT).", "error")
            return redirect(url_for("candidates"))
        added, failed = 0, []
        for f in files:
            if not allowed_file(f.filename):
                failed.append(f.filename)
                continue
            safe = f"{uuid.uuid4().hex[:8]}_{secure_filename(f.filename)}"
            path = os.path.join(UPLOAD_DIR, safe)
            f.save(path)
            text = extract_text(path)
            if len(text) < 30:
                os.remove(path)
                failed.append(f.filename)
                continue
            stem = os.path.splitext(secure_filename(f.filename))[0].replace("_", " ").replace("-", " ").title()
            p = extract_profile(text, fallback_name=stem)
            cid = cm.add_candidate(p["name"], p["email"], p["phone"], p["education"],
                                   p["experience_years"], ",".join(p["skills"]), safe, text)
            run_matching(candidate_id=cid)
            added += 1
        if added:
            flash(f"{added} resume(s) parsed and matched against all jobs.", "ok")
        if failed:
            flash("Could not read: " + ", ".join(failed) + ". Use text-based PDF, DOCX or TXT files.", "error")
        return redirect(url_for("candidates"))
    q = request.args.get("q", "").strip()
    return render_template("candidates.html", candidates=cm.list_candidates(q or None), q=q)


@app.route("/candidates/<int:cid>")
@login_required
def candidate_profile(cid):
    cand = cm.get_candidate(cid)
    if not cand:
        return redirect(url_for("candidates"))
    apps = cm.applications_for_candidate(cid)
    best = apps[0] if apps else None
    gaps = skill_gap_advice((best["missing_skills"] or "").split(",") if best and best["missing_skills"] else [])
    return render_template("candidate_profile.html", c=cand, apps=apps,
                           recs=recommend_jobs(apps), gaps=gaps, best=best)


@app.route("/candidates/<int:cid>/delete", methods=["POST"])
@login_required
def delete_candidate(cid):
    cand = cm.get_candidate(cid)
    if cand:
        if cand["resume_path"]:
            try:
                os.remove(os.path.join(UPLOAD_DIR, cand["resume_path"]))
            except OSError:
                pass
        cm.delete_candidate(cid)
        flash("Candidate removed.", "ok")
    return redirect(url_for("candidates"))


@app.route("/applications/<int:app_id>/status", methods=["POST"])
@login_required
def update_status(app_id):
    status = request.form.get("status")
    if status in STATUSES:
        row = cm.set_application_status(app_id, status)
        if row:
            return redirect(request.form.get("next") or url_for("job_detail", job_id=row["job_id"]))
    return redirect(url_for("dashboard"))


# ---------------- analytics ----------------
@app.route("/analytics")
@login_required
def analytics():
    return render_template("analytics.html", data=cm.analytics())


@app.route("/api/analytics")
@login_required
def analytics_api():
    return jsonify(cm.analytics())


@app.errorhandler(413)
def too_large(_):
    flash("That upload is over 5 MB. Try a smaller file.", "error")
    return redirect(url_for("candidates"))


if __name__ == "__main__":
    app.run(debug=True)
