// Renders the analytics charts. Expects window.ANALYTICS to be set by the page.
(function () {
  if (!window.Chart || !window.ANALYTICS) return;
  var d = window.ANALYTICS;
  var css = getComputedStyle(document.documentElement);
  var accent = css.getPropertyValue("--accent").trim() || "#0d6b78";
  var muted = css.getPropertyValue("--muted").trim() || "#5d6b78";
  var line = css.getPropertyValue("--line").trim() || "#dde2e7";
  Chart.defaults.color = muted;
  Chart.defaults.font.family = '"IBM Plex Sans","Segoe UI",system-ui,sans-serif';
  var grid = { color: line };
  var base = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } };

  function make(id, cfg) { var el = document.getElementById(id); if (el) new Chart(el, cfg); }

  make("scoreChart", {
    type: "bar",
    data: { labels: Object.keys(d.score_buckets), datasets: [{ data: Object.values(d.score_buckets), backgroundColor: accent }] },
    options: Object.assign({}, base, { scales: { y: { beginAtZero: true, ticks: { precision: 0 }, grid: grid }, x: { grid: { display: false } } } })
  });

  make("jobChart", {
    type: "bar",
    data: { labels: d.per_job.map(function (j) { return j.title; }),
            datasets: [{ data: d.per_job.map(function (j) { return j.avg_score; }), backgroundColor: accent }] },
    options: Object.assign({}, base, { indexAxis: "y", scales: { x: { beginAtZero: true, max: 100, grid: grid }, y: { grid: { display: false } } } })
  });

  make("skillChart", {
    type: "bar",
    data: { labels: d.top_skills.map(function (s) { return s[0]; }),
            datasets: [{ data: d.top_skills.map(function (s) { return s[1]; }), backgroundColor: accent }] },
    options: Object.assign({}, base, { indexAxis: "y", scales: { x: { beginAtZero: true, ticks: { precision: 0 }, grid: grid }, y: { grid: { display: false } } } })
  });

  make("statusChart", {
    type: "doughnut",
    data: { labels: Object.keys(d.status), datasets: [{ data: Object.values(d.status),
            backgroundColor: ["#0d6b78", "#4fb3c0", "#b57a12", "#1f7a4d", "#9aa5af"] }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }
  });
})();
