"""Data-access helpers for jobs, candidates and applications."""
from models.database import get_db


# ---------- jobs ----------
def add_job(title, department, location, description, required_skills, min_experience):
    conn = get_db()
    cur = conn.execute(
        """INSERT INTO jobs (title, department, location, description, required_skills, min_experience)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (title, department, location, description, required_skills, min_experience),
    )
    conn.commit()
    job_id = cur.lastrowid
    conn.close()
    return job_id


def list_jobs(status=None):
    conn = get_db()
    sql = """SELECT j.*, COUNT(a.id) AS applicant_count,
                    ROUND(AVG(a.final_score), 1) AS avg_score
             FROM jobs j LEFT JOIN applications a ON a.job_id = j.id"""
    params = ()
    if status:
        sql += " WHERE j.status = ?"
        params = (status,)
    sql += " GROUP BY j.id ORDER BY j.created_at DESC, j.id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return rows


def get_job(job_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    conn.close()
    return row


def set_job_status(job_id, status):
    conn = get_db()
    conn.execute("UPDATE jobs SET status = ? WHERE id = ?", (status, job_id))
    conn.commit()
    conn.close()


def delete_job(job_id):
    conn = get_db()
    conn.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
    conn.commit()
    conn.close()


# ---------- candidates ----------
def add_candidate(name, email, phone, education, experience_years, skills, resume_path, resume_text):
    conn = get_db()
    cur = conn.execute(
        """INSERT INTO candidates
           (name, email, phone, education, experience_years, skills, resume_path, resume_text)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (name, email, phone, education, experience_years, skills, resume_path, resume_text),
    )
    conn.commit()
    cid = cur.lastrowid
    conn.close()
    return cid


def list_candidates(search=None):
    conn = get_db()
    sql = """SELECT c.*, MAX(a.final_score) AS best_score
             FROM candidates c LEFT JOIN applications a ON a.candidate_id = c.id"""
    params = ()
    if search:
        sql += " WHERE c.name LIKE ? OR c.skills LIKE ? OR c.email LIKE ?"
        like = f"%{search}%"
        params = (like, like, like)
    sql += " GROUP BY c.id ORDER BY c.created_at DESC, c.id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return rows


def get_candidate(cid):
    conn = get_db()
    row = conn.execute("SELECT * FROM candidates WHERE id = ?", (cid,)).fetchone()
    conn.close()
    return row


def delete_candidate(cid):
    conn = get_db()
    conn.execute("DELETE FROM candidates WHERE id = ?", (cid,))
    conn.commit()
    conn.close()


# ---------- applications (match results) ----------
def upsert_application(job_id, candidate_id, r):
    """Store/refresh a match result. Keeps any recruiter-set status."""
    conn = get_db()
    conn.execute(
        """INSERT INTO applications
           (job_id, candidate_id, skill_score, text_score, exp_score, final_score,
            matched_skills, missing_skills)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(job_id, candidate_id) DO UPDATE SET
             skill_score = excluded.skill_score,
             text_score = excluded.text_score,
             exp_score = excluded.exp_score,
             final_score = excluded.final_score,
             matched_skills = excluded.matched_skills,
             missing_skills = excluded.missing_skills""",
        (
            job_id, candidate_id, r["skill_score"], r["text_score"], r["exp_score"],
            r["final_score"], ",".join(r["matched"]), ",".join(r["missing"]),
        ),
    )
    conn.commit()
    conn.close()


def applications_for_job(job_id):
    conn = get_db()
    rows = conn.execute(
        """SELECT a.*, c.name, c.email, c.experience_years, c.skills, c.education
           FROM applications a JOIN candidates c ON c.id = a.candidate_id
           WHERE a.job_id = ?""",
        (job_id,),
    ).fetchall()
    conn.close()
    return rows


def applications_for_candidate(cid):
    conn = get_db()
    rows = conn.execute(
        """SELECT a.*, j.title, j.department, j.location, j.status AS job_status
           FROM applications a JOIN jobs j ON j.id = a.job_id
           WHERE a.candidate_id = ? ORDER BY a.final_score DESC""",
        (cid,),
    ).fetchall()
    conn.close()
    return rows


def set_application_status(app_id, status):
    conn = get_db()
    conn.execute("UPDATE applications SET status = ? WHERE id = ?", (status, app_id))
    conn.commit()
    row = conn.execute("SELECT job_id, candidate_id FROM applications WHERE id = ?", (app_id,)).fetchone()
    conn.close()
    return row


# ---------- analytics ----------
def analytics():
    conn = get_db()
    q = lambda sql, p=(): conn.execute(sql, p).fetchall()
    data = {
        "totals": {
            "jobs": conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0],
            "open_jobs": conn.execute("SELECT COUNT(*) FROM jobs WHERE status='open'").fetchone()[0],
            "candidates": conn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0],
            "applications": conn.execute("SELECT COUNT(*) FROM applications").fetchone()[0],
            "avg_score": conn.execute("SELECT ROUND(COALESCE(AVG(final_score),0),1) FROM applications").fetchone()[0],
        },
        "status": {r["status"]: r["n"] for r in q("SELECT status, COUNT(*) n FROM applications GROUP BY status")},
        "per_job": [dict(r) for r in q(
            """SELECT j.title, COUNT(a.id) AS applicants, ROUND(COALESCE(AVG(a.final_score),0),1) AS avg_score
               FROM jobs j LEFT JOIN applications a ON a.job_id = j.id GROUP BY j.id ORDER BY j.id""")],
        "score_buckets": {
            "0-39": conn.execute("SELECT COUNT(*) FROM applications WHERE final_score < 40").fetchone()[0],
            "40-59": conn.execute("SELECT COUNT(*) FROM applications WHERE final_score >= 40 AND final_score < 60").fetchone()[0],
            "60-79": conn.execute("SELECT COUNT(*) FROM applications WHERE final_score >= 60 AND final_score < 80").fetchone()[0],
            "80-100": conn.execute("SELECT COUNT(*) FROM applications WHERE final_score >= 80").fetchone()[0],
        },
    }
    skill_counts = {}
    for r in q("SELECT skills FROM candidates"):
        for s in filter(None, (r["skills"] or "").split(",")):
            skill_counts[s] = skill_counts.get(s, 0) + 1
    data["top_skills"] = sorted(skill_counts.items(), key=lambda kv: -kv[1])[:10]
    conn.close()
    return data
