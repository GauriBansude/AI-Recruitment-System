"""SQLite connection + schema for the recruitment system."""
import os
import sqlite3
from werkzeug.security import generate_password_hash

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    department TEXT,
    location TEXT,
    description TEXT NOT NULL,
    required_skills TEXT DEFAULT '',
    min_experience REAL DEFAULT 0,
    status TEXT DEFAULT 'open',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    education TEXT,
    experience_years REAL DEFAULT 0,
    skills TEXT DEFAULT '',
    resume_path TEXT,
    resume_text TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    candidate_id INTEGER NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
    skill_score REAL DEFAULT 0,
    text_score REAL DEFAULT 0,
    exp_score REAL DEFAULT 0,
    final_score REAL DEFAULT 0,
    matched_skills TEXT DEFAULT '',
    missing_skills TEXT DEFAULT '',
    status TEXT DEFAULT 'new',
    UNIQUE (job_id, candidate_id)
);
"""


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create tables and a default admin account (admin / admin123)."""
    conn = get_db()
    conn.executescript(SCHEMA)
    exists = conn.execute("SELECT 1 FROM users WHERE username = 'admin'").fetchone()
    if not exists:
        conn.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            ("admin", generate_password_hash("admin123")),
        )
    conn.commit()
    conn.close()
