# TalentLens - AI Recruitment System

A Flask web app that reads resumes, extracts skills, scores every candidate against every job, and ranks them for recruiters.

## How the matching works
Each candidate-job pair gets three scores (0-100), combined in `modules/ranking.py`:

| Signal | How it's calculated | Weight |
|---|---|---|
| Skill match | share of the job's required skills found on the resume | 60% |
| Text similarity | TF-IDF cosine similarity of resume text vs. job description | 25% |
| Experience | candidate years vs. the job's minimum | 15% |

Final score: 75+ = Strong match, 50-74 = Potential, below 50 = Weak match.

## Run it
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python seed.py          # optional: demo jobs + sample resumes
python app.py
```
Open http://127.0.0.1:5000 and log in with `admin` / `admin123`.
Set `SECRET_KEY` as an environment variable before using this anywhere real, and change the admin password.

## Project layout
- `app.py` - routes (login, jobs, candidates, analytics, status updates)
- `models/` - SQLite schema and queries
- `modules/resume_parser.py` - PDF / DOCX / TXT to text
- `modules/skill_extractor.py` - skills, contact info, experience, education (edit the `SKILLS` dict to add skills)
- `modules/job_matcher.py` - the three match signals
- `modules/ranking.py` - weights, final score, ranking, tiers
- `modules/recommendation.py` - role recommendations and skill-gap tips
- `templates/`, `static/` - UI

## Ideas to extend
Email shortlisted candidates, swap TF-IDF for sentence embeddings, add recruiter roles, export rankings to CSV.
