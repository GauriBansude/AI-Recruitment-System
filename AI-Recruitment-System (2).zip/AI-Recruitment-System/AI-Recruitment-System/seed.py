"""Load demo jobs + the sample resumes so you can see the app working.  Run: python seed.py"""
import glob
import os
import shutil

import app as recruit
from models import candidate_model as cm
from modules.resume_parser import extract_text
from modules.skill_extractor import extract_profile, parse_skill_list

JOBS = [
    ("Business Analyst", "Operations", "Pune", 2,
     "Work with stakeholders to gather requirements, analyse data, document processes and present findings to leadership.",
     "business analysis, sql, excel, communication, stakeholder management, documentation"),
    ("HR Recruiter", "People", "Mumbai", 2,
     "Own end-to-end recruitment: sourcing, screening, coordinating interviews and onboarding new joiners.",
     "recruitment, onboarding, communication, ms office, teamwork"),
    ("Machine Learning Engineer", "Engineering", "Remote", 2,
     "Build and deploy ML and NLP models, expose them through REST APIs and containerise services.",
     "python, machine learning, nlp, flask, docker, git"),
]

if __name__ == "__main__":
    if cm.list_jobs():
        print("Database already has jobs - delete database.db to reseed.")
        raise SystemExit
    for title, dept, loc, exp, desc, skills in JOBS:
        cm.add_job(title, dept, loc, desc, ",".join(parse_skill_list(skills)), exp)
    for path in sorted(glob.glob("sample_resumes/*.txt")):
        name = os.path.basename(path)
        dest = os.path.join(recruit.UPLOAD_DIR, name)
        shutil.copy(path, dest)
        text = extract_text(dest)
        p = extract_profile(text, fallback_name=name)
        cm.add_candidate(p["name"], p["email"], p["phone"], p["education"], p["experience_years"],
                         ",".join(p["skills"]), name, text)
    recruit.run_matching()
    print("Seeded 3 jobs and 3 candidates. Run: python app.py  (login admin / admin123)")
