"""Pull structured details (skills, contact info, experience, education) out of resume text."""
import re

# canonical skill -> aliases that should also match. Extend freely.
SKILLS = {
    # languages & data
    "python": ["python"], "java": ["java"], "javascript": ["javascript", "js"],
    "typescript": ["typescript"], "c++": ["c++"], "c#": ["c#"], "sql": ["sql", "mysql", "postgresql", "postgres", "sqlite"],
    "r": [r"r programming"], "excel": ["excel", "advanced excel"], "power bi": ["power bi", "powerbi"],
    "tableau": ["tableau"], "pandas": ["pandas"], "numpy": ["numpy"],
    # AI / ML
    "machine learning": ["machine learning", "ml"], "deep learning": ["deep learning"],
    "nlp": ["nlp", "natural language processing"], "computer vision": ["computer vision", "opencv"],
    "tensorflow": ["tensorflow"], "pytorch": ["pytorch"], "scikit-learn": ["scikit-learn", "sklearn"],
    "data analysis": ["data analysis", "data analytics"], "data visualization": ["data visualization", "data visualisation"],
    "statistics": ["statistics", "statistical analysis"],
    # web / cloud / tools
    "flask": ["flask"], "django": ["django"], "react": ["react", "reactjs", "react.js"],
    "html": ["html", "html5"], "css": ["css", "css3"], "rest api": ["rest api", "restful", "rest apis"],
    "aws": ["aws", "amazon web services"], "azure": ["azure"], "docker": ["docker"], "git": ["git", "github"],
    "linux": ["linux"], "jira": ["jira"],
    # business / people skills
    "communication": ["communication", "communication skills"], "leadership": ["leadership", "team lead"],
    "teamwork": ["teamwork", "team player", "collaboration"], "project management": ["project management", "project manager"],
    "agile": ["agile", "scrum"], "recruitment": ["recruitment", "talent acquisition", "recruiting", "sourcing"],
    "onboarding": ["onboarding"], "stakeholder management": ["stakeholder management", "stakeholder"],
    "business analysis": ["business analysis", "business analyst", "requirements gathering"],
    "documentation": ["documentation", "technical writing"], "presentation": ["presentation", "presentations", "public speaking"],
    "problem solving": ["problem solving", "problem-solving"], "time management": ["time management"],
    "customer service": ["customer service", "client handling", "client management"],
    "hr operations": ["hr operations", "human resources", "payroll", "employee engagement"],
    "event management": ["event management", "event coordination"], "market research": ["market research"],
    "ms office": ["ms office", "microsoft office"], "sap": ["sap"], "salesforce": ["salesforce", "crm"],
    "testing": ["manual testing", "qa", "quality assurance", "test cases"], "ui/ux": ["ui/ux", "ux", "figma"],
}

DEGREE_RANK = [
    ("phd", r"\bph\.?d\b|doctorate"),
    ("MBA", r"\bmba\b|master of business"),
    ("Master's", r"\bm\.?tech\b|\bm\.?e\b\.?|\bm\.?sc\b|\bmaster'?s?\b|\bmca\b"),
    ("Bachelor's", r"\bb\.?tech\b|\bb\.?e\b\.?|\bb\.?sc\b|\bbachelor'?s?\b|\bbca\b|\bb\.?com\b|\bbba\b"),
    ("Diploma", r"\bdiploma\b"),
]

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE_RE = re.compile(r"(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{3,5}\)?[\s-]?)?\d{3,5}[\s-]?\d{4,5}")
YEARS_RE = re.compile(r"(\d{1,2})(?:\.\d)?\s*\+?\s*(?:years?|yrs?)", re.I)
RANGE_RE = re.compile(r"((?:19|20)\d{2})\s*(?:-|–|—|to)\s*((?:19|20)\d{2}|present|current|now)", re.I)


def _pattern(alias):
    return re.compile(r"(?<![\w+#])" + (alias if alias.startswith("r ") else re.escape(alias)) + r"(?![\w+#])", re.I)


_COMPILED = {skill: [_pattern(a) for a in aliases] for skill, aliases in SKILLS.items()}
# 'r programming' alias is already regex-safe; fix the single-letter case:
_COMPILED["r"] = [re.compile(r"\br programming\b", re.I)]


def extract_skills(text):
    found = [s for s, pats in _COMPILED.items() if any(p.search(text) for p in pats)]
    return sorted(found)


def extract_email(text):
    m = EMAIL_RE.search(text)
    return m.group(0) if m else ""


def extract_phone(text):
    for m in PHONE_RE.finditer(text):
        digits = re.sub(r"\D", "", m.group(0))
        if 10 <= len(digits) <= 13:
            return m.group(0).strip()
    return ""


def extract_name(text, fallback=""):
    skip = ("resume", "curriculum", "vitae", "profile", "contact", "objective", "summary")
    for line in [l.strip() for l in text.splitlines() if l.strip()][:6]:
        if "@" in line or any(ch.isdigit() for ch in line) or any(w in line.lower() for w in skip):
            continue
        words = line.split()
        if 2 <= len(words) <= 4 and all(re.fullmatch(r"[A-Za-z.'-]+", w) for w in words):
            return line.title() if line.isupper() else line
    return fallback


def extract_experience_years(text):
    stated = [int(m.group(1)) for m in YEARS_RE.finditer(text)]
    stated = [y for y in stated if y <= 40]
    if stated:
        return float(max(stated))
    total = 0
    for m in RANGE_RE.finditer(text):
        start = int(m.group(1))
        end_raw = m.group(2).lower()
        end = 2026 if end_raw in ("present", "current", "now") else int(end_raw)
        if 0 <= end - start <= 30:
            total += end - start
    return float(min(total, 40))


def extract_education(text):
    for label, pattern in DEGREE_RANK:
        if re.search(pattern, text, re.I):
            return label
    return ""


def extract_profile(text, fallback_name=""):
    return {
        "name": extract_name(text, fallback_name) or fallback_name or "Unknown candidate",
        "email": extract_email(text),
        "phone": extract_phone(text),
        "education": extract_education(text),
        "experience_years": extract_experience_years(text),
        "skills": extract_skills(text),
    }


def parse_skill_list(raw):
    """'Python, SQL ,  Excel' -> ['python','sql','excel'] (canonicalised where possible)."""
    out = []
    for token in re.split(r"[,\n;]", raw or ""):
        t = token.strip().lower()
        if not t:
            continue
        for canon, aliases in SKILLS.items():
            if t == canon or t in [a.lower() for a in aliases]:
                t = canon
                break
        if t not in out:
            out.append(t)
    return out
