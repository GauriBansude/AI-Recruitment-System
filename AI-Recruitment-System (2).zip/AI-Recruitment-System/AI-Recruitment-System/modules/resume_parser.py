"""Turn an uploaded resume (PDF / DOCX / TXT) into plain text."""
import os

ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def _read_pdf(path):
    from pypdf import PdfReader
    reader = PdfReader(path)
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def _read_docx(path):
    from docx import Document
    doc = Document(path)
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            parts.append(" | ".join(cell.text for cell in row.cells))
    return "\n".join(parts)


def _read_txt(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def extract_text(path):
    """Return the text of a resume file, or '' if it cannot be read."""
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    try:
        if ext == "pdf":
            text = _read_pdf(path)
        elif ext == "docx":
            text = _read_docx(path)
        else:
            text = _read_txt(path)
    except Exception:
        return ""
    return text.replace("\x00", " ").strip()
