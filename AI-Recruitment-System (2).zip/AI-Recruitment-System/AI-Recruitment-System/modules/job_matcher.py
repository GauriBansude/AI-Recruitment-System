"""Score one candidate against one job.

Three signals are produced (each 0-100):
  skill_score - share of the job's required skills the candidate has
  text_score  - TF-IDF cosine similarity between resume text and job description
  exp_score   - candidate experience vs. the job's minimum
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from modules.skill_extractor import extract_skills, parse_skill_list


def _split(s):
    return [x for x in (s or "").split(",") if x]


def text_similarity(resume_text, job_text):
    if not resume_text.strip() or not job_text.strip():
        return 0.0
    try:
        vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        m = vec.fit_transform([resume_text, job_text])
        return float(cosine_similarity(m[0], m[1])[0][0]) * 100
    except ValueError:  # empty vocabulary
        return 0.0


def match_candidate_to_job(candidate, job):
    cand_skills = set(_split(candidate["skills"]))
    required = parse_skill_list(job["required_skills"])
    if not required:  # fall back to skills mentioned in the description
        required = extract_skills(job["description"])

    matched = [s for s in required if s in cand_skills]
    missing = [s for s in required if s not in cand_skills]
    skill_score = (len(matched) / len(required) * 100) if required else 0.0

    text_score = text_similarity(
        candidate["resume_text"] or "",
        f"{job['title']} {job['description']} {job['required_skills'] or ''}",
    )

    min_exp = float(job["min_experience"] or 0)
    cand_exp = float(candidate["experience_years"] or 0)
    exp_score = 100.0 if min_exp <= 0 else min(cand_exp / min_exp, 1.0) * 100

    return {
        "skill_score": round(skill_score, 1),
        "text_score": round(min(text_score * 2.5, 100), 1),  # raw cosine is small; rescale
        "exp_score": round(exp_score, 1),
        "matched": matched,
        "missing": missing,
    }
