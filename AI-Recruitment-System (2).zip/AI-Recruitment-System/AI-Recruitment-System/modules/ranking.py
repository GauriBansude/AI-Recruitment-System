"""Combine match signals into a final score and rank candidates."""

WEIGHTS = {"skill": 0.60, "text": 0.25, "exp": 0.15}


def final_score(result):
    score = (
        WEIGHTS["skill"] * result["skill_score"]
        + WEIGHTS["text"] * result["text_score"]
        + WEIGHTS["exp"] * result["exp_score"]
    )
    return round(score, 1)


def tier(score):
    if score >= 75:
        return "Strong match"
    if score >= 50:
        return "Potential"
    return "Weak match"


def rank_applications(rows):
    """Sort application rows by final score (desc) and attach rank + tier."""
    ordered = sorted(rows, key=lambda r: (-r["final_score"], r["name"].lower()))
    ranked = []
    for i, r in enumerate(ordered, start=1):
        d = dict(r)
        d["rank"] = i
        d["tier"] = tier(d["final_score"])
        ranked.append(d)
    return ranked
