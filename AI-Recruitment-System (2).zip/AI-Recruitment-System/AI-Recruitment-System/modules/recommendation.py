"""Recommendations: which jobs suit a candidate, and what skills to close gaps."""
from modules.ranking import tier

LEARNING_HINTS = {
    "python": "Complete a beginner Python course and build one small automation script.",
    "sql": "Practise joins and aggregations on a sample database.",
    "excel": "Learn pivot tables, lookups and basic dashboards.",
    "power bi": "Build a one-page dashboard from a public dataset.",
    "communication": "Show it: add presentations, mentoring or client-facing work to the resume.",
    "project management": "Take a short Agile/Scrum course and list a project you coordinated.",
    "agile": "Learn Scrum ceremonies and roles; a Scrum Master fundamentals badge helps.",
    "recruitment": "Shadow a recruiter or do a talent-acquisition fundamentals course.",
    "documentation": "Publish sample documentation or process notes in a portfolio.",
    "stakeholder management": "Describe a case where you aligned several people on a decision.",
}


def recommend_jobs(applications, limit=3):
    """applications: rows for one candidate (already scored). Open jobs only, best first."""
    open_jobs = [a for a in applications if a["job_status"] == "open"]
    out = []
    for a in sorted(open_jobs, key=lambda r: -r["final_score"])[:limit]:
        out.append({"job_id": a["job_id"], "title": a["title"],
                    "score": a["final_score"], "tier": tier(a["final_score"])})
    return out


def skill_gap_advice(missing_skills, limit=5):
    advice = []
    for s in missing_skills[:limit]:
        advice.append({"skill": s, "tip": LEARNING_HINTS.get(
            s, f"Add hands-on evidence of {s} (a course, project or work example).")})
    return advice
